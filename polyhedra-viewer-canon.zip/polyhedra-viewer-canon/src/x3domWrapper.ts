// eslint-disable-next-line import/no-webpack-loader-syntax
import x3dom from "exports-loader?x3dom!x3dom"
export default x3dom
