export { default } from "./InfoPanel"
