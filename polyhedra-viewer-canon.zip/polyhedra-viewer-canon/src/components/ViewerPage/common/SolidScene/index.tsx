import SolidScene from "./SolidScene"
export default SolidScene
