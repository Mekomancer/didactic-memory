import React from "react"
import { Link } from "react-router-dom"

import { escape } from "utils"
import { square, hover, flexRow } from "styles/common"
import { useStyle, media } from "styles"

interface Props {
  name: string
  isFake: boolean
}

// using raw pixel values since we need to do math
const thumbnailSize = 64
const mobThumbnailSize = 48

function Image({ name }: Pick<Props, "name">) {
  const css = useStyle({
    ...flexRow("center", "center"),
    [media.notMobile]: {
      height: thumbnailSize,
    },
    [media.mobile]: {
      height: mobThumbnailSize,
    },
  })
  const escapedName = escape(name)
  return (
    <img
      {...css()}
      alt={name}
      src={require(`images/thumbnails/${escapedName}.png`)}
    />
  )
}

export default function PolyhedronLink({ name, isFake }: Props) {
  const escapedName = escape(name)

  const css = useStyle(
    {
      ...hover,
      ...(isFake ? { opacity: 0.5, filter: "grayscale(50%)" } : {}),
      ...flexRow("center", "center"),
      border: "1px LightGray solid",
      color: "black",
      overflow: "hidden",
      margin: "auto", // center inside a table
      borderRadius: ".5rem",
      [media.notMobile]: square(thumbnailSize),
      [media.mobile]: square(mobThumbnailSize),
    },
    [isFake],
  )
  return (
    <Link
      {...css()}
      id={!isFake ? escapedName : undefined}
      to={"/" + escapedName}
      title={name}
    >
      <Image name={name} />
    </Link>
  )
}
