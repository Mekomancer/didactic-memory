declare module "exports-loader?x3dom!x3dom" {
  const x3dom: {
    Viewarea: any
    reload(): void
  }

  export default x3dom
}
