export const times = ["Times New Roman", "Times", "serif"]

export const andaleMono = ["Andale Mono", "AndaleMono", "monospace"]

export const verdana = ["Verdana", "Geneva", "sans-serif"]
