export default {
  reload() {},
}
