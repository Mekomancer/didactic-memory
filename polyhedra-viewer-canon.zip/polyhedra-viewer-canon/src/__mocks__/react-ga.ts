export default {
  initialize: jest.fn(),
  pageview: jest.fn(),
}
